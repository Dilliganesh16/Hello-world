import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProfileServiceService {
  configUrl = "http://localhost:3000/api/people"
  constructor(private http:HttpClient) { }
  getaddress() {
    return this.http.get(this.configUrl);
  }
}
