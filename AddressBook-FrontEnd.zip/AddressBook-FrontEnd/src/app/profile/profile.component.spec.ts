import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule } from '@angular/platform-browser';
import { ProfileComponent } from './profile.component';
import { AppRoutingModule } from '../app-routing.module';
import {ProfileServiceService } from '../profile-service.service';
import { HttpClientModule, HttpClient } from '@angular/common/http';

describe('ProfileComponent', () => {
  let component: ProfileComponent;
  let fixture: ComponentFixture<ProfileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProfileComponent ],
      
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule
  ],
      providers: [HttpClientModule,ProfileServiceService]
    })
    .compileComponents().then(()=>{
      fixture = TestBed.createComponent(ProfileComponent);
      component = fixture.componentInstance;
      
    });
  });


  it('should create', () => {
    fixture.detectChanges();

  });
});
