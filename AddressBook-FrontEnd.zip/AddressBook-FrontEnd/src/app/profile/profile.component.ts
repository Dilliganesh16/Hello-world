import { Component, OnInit } from '@angular/core';
import { ProfileServiceService } from '../profile-service.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  
  selectedPerson:any = [];
  peopleAddress =[];
  isDataAvailable = false;
  
  // peopleAddress = [
  //     {
  //       "name": "Joe Manfrey",
  //       "email": "joe@food.com",
  //       "phone": "(555)987-6543",
  //       "profileImage": "images/joe.jpg",
  //       "education": [{
  //         "institution": "Clemson University",
  //         "startYear": 1990,
  //         "endYear": 1995,
  //         "degree": "Bachelor's, Computer Science"
  //       }],
  
  //       "workExperience": [{
  //         "institution": "Food Inc.",
  //         "startYear": 1998,
  //         "title": "Software Developer"
  //       }]
  //     },
  //     {
  //       "name": "Douglas Cho",
  //       "email": "doug@food.com",
  //       "phone": "(555)246-8101",
  //       "profileImage": "images/doug.jpg",
  //       "education": [{
  //         "institution": "University of NC, Chapel Hill",
  //         "startYear": 1990,
  //         "endYear": 1995,
  //         "degree": "Marketing"
  //       }],
  
  //       "workExperience": [{
  //         "institution": "Food Inc.",
  //         "startYear": 1998,
  //         "title": "Software Developer"
  //       }]
  //     },
  //     {
  //       "name": "Allison Murray",
  //       "email": "allison@up.com",
  //       "phone": "(555)444-3333",
  //       "profileImage": "images/allison.jpg",
  //       "education": [{
  //         "institution": "University of Southern California",
  //         "startYear": 2001,
  //         "endYear": 2005,
  //         "degree": "Sociology"
  //       }],
  
  //       "workExperience": [{
  //         "institution": "United Products",
  //         "startYear": 1998,
  //         "title": "Directory of IT"
  //       }]
  //     }
  //   ]
  
  
  constructor(private peopleService : ProfileServiceService) { 
  
    // this.selectedPerson = this.peopleAddress[0];
    
  }

  ngOnInit(): void {
    this.peopleService.getaddress()
    .subscribe((data:any) => {
      this.peopleAddress = data.people;
      console.log(this.peopleAddress)
      this.selectedPerson = [this.peopleAddress[0]];
      this.isDataAvailable = true
    }
    );
  }
  ascenSort(){
    return this.peopleAddress.sort((a, b) => a['name'] > b['name'] ? 1 : a['name'] === b['name'] ? 0 : -1);
    //return values.sort((a, b) => a.name.localeCompare(b.name));
  }
  descSort(){
    return this.peopleAddress.sort((a, b) => a['name'] < b['name'] ? 1 : a['name'] === b['name'] ? 0 : -1);
  }
  showAddress(email:string){
    this.selectedPerson = this.peopleAddress.filter(x=>x['email'] == email)
  }

}
