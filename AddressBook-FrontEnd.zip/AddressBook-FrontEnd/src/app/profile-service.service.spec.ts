import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController
} from "@angular/common/http/testing";
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { BrowserModule } from '@angular/platform-browser';

import { ProfileServiceService } from './profile-service.service';

describe('ProfileServiceService', () => {
  let service: ProfileServiceService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        BrowserModule,
        HttpClientModule,
        AppRoutingModule
      ],
      providers: [HttpClientModule,ProfileServiceService]
    });
    service = TestBed.inject(ProfileServiceService);
  });

  it('should be created', () => {
    const people  = {"people":[{
			"name": "Adam Wright",
			"email": "adam@megacorp.com",
			"phone": "(555)123-1234",
			"profileImage": "images/adam.jpg",
			"education": [{
				"institution": "NC State University",
				"startYear": 2001,
				"endYear": 2004,
				"degree": "Bachelor's, Computer Science"
			}],

			"workExperience": [{
					"institution": "Megacorp",
					"startYear": 2001,
					"title": "Software Developer"
				},
				{
					"institution": "Food Inc.",
					"startYear": 1998,
					"endYear": 2001,
					"title": "Software Developer"
				}
			]
		},
		{
			"name": "Joe Manfrey",
			"email": "joe@food.com",
			"phone": "(555)987-6543",
			"profileImage": "images/joe.jpg",
			"education": [{
				"institution": "Clemson University",
				"startYear": 1990,
				"endYear": 1995,
				"degree": "Bachelor's, Computer Science"
			}],

			"workExperience": [{
				"institution": "Food Inc.",
				"startYear": 1998,
				"title": "Software Developer"
			}]
		},
		{
			"name": "Douglas Cho",
			"email": "doug@food.com",
			"phone": "(555)246-8101",
			"profileImage": "images/doug.jpg",
			"education": [{
				"institution": "University of NC, Chapel Hill",
				"startYear": 1990,
				"endYear": 1995,
				"degree": "Marketing"
			}],

			"workExperience": [{
				"institution": "Food Inc.",
				"startYear": 1998,
				"title": "Software Developer"
			}]
		},
		{
			"name": "Allison Murray",
			"email": "allison@up.com",
			"phone": "(555)444-3333",
			"profileImage": "images/allison.jpg",
			"education": [{
				"institution": "University of Southern California",
				"startYear": 2001,
				"endYear": 2005,
				"degree": "Sociology"
			}],

			"workExperience": [{
				"institution": "United Products",
				"startYear": 1998,
				"title": "Directory of IT"
			}]
		}
	]};
  const service: ProfileServiceService = TestBed.get(ProfileServiceService);
  expect(service).toBeTruthy();
    // service.getaddress().subscribe((res) => {
    //   expect(res).toEqual(people);
    // });

    // const req = httpMock.expectOne({ method: 'GET', url: 'http://localhost:4200/app' });
    // req.flush(people);

    // httpMock.verify();
  });

it('should have getData function', () => {
  const service: ProfileServiceService = TestBed.get(ProfileServiceService);
  expect(service).toBeTruthy();
 });
});
