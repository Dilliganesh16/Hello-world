const express = require('express'),
http = require('http'),
cors = require('cors'),
fs = require('fs')
const app = express()
const port = 3000
app.options('*', cors())
app.get('/api/people', cors(),(req, res) => {
    fs.readFile('people.json', (err, data) => {
        if (err) throw err;
        let people = JSON.parse(data);
        console.log(people);
        res.send(people)
    });
})

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
})